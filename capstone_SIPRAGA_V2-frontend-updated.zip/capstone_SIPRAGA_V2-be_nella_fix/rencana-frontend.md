# Rencana Frontend — CORETAX V2

Dokumen ini mencatat audit, perubahan yang sudah diterapkan, dan rekomendasi lanjutan untuk perbaikan UI/UX frontend CORETAX (responsif web + mobile, palet warna baru, ikon lucide-react).

## 1. Palet Warna Baru

Didefinisikan sebagai CSS variables di `src/index.css` (Tailwind v4 `@theme`), sehingga otomatis tersedia sebagai utility class (`bg-primary`, `text-accent`, dll juga bisa lewat `var(--color-...)`):

| Token | Hex | Pemakaian |
|---|---|---|
| `--color-primary` | `#112E81` | Sidebar, header, tombol utama, teks aksen navy |
| `--color-primary-dark` | `#0A1F5C` | Hover/active state gelap, sidebar RT/RW & superadmin |
| `--color-primary-light` | `#2945A8` | Hover state terang, gradient |
| `--color-accent` | `#FAB95B` | Highlight, badge aktif sidebar, CTA sekunder |
| `--color-accent-dark` / `-light` | `#E5A23F` / `#FFD699` | Variasi aksen |
| `--color-surface` | `#E8E2DB` | Background utama aplikasi (warm neutral) |
| `--color-surface-card` | `#FFFFFF` | Kartu, modal, panel |
| `--color-surface-muted` | `#F4F1EC` | Background section, hover halus |
| `--color-surface-border` | `#DDD6CC` | Border kartu, tabel, input |
| `--color-danger` | `#D51C39` | Tolak, hapus, error, validasi |
| `--color-status-*` | — | Badge status MENUNGGU (amber) / DISETUJUI (hijau) / DITOLAK (merah) |

Alias `brand-*` dan `ink*` dipertahankan agar komponen lama (`NotificationBell`, dll) yang sudah memakai token tersebut langsung valid tanpa refactor besar.

## 2. Ikon — Migrasi ke lucide-react

Semua ikon SVG inline (hasil generate lama) sudah/harus diganti ke `lucide-react` (sudah terpasang di `package.json`). Sudah diterapkan di:
- `Logo.jsx` → `Landmark`
- `EmptyState.jsx` → `FileText`
- Seluruh komponen wizard (`Step1`–`Step8`) → `FileText`, `UploadCloud`, `X`, `ChevronRight`, `Info`, `AlertCircle`, `CheckCircle2`, `Send`, `Eye`
- `DashboardLayout.jsx` sudah memakai lucide-react sebelumnya — dipertahankan, palet sidebar diselaraskan

**Rekomendasi lanjutan:** sapu sisa SVG inline di `LetterDetailPage.jsx`, `RegisterRtRw.jsx`, `RegisterWarga.jsx`, halaman superadmin — ganti pola `<svg className="w-X h-X" ...><path .../></svg>` dengan komponen lucide yang setara (`CheckCircle2`, `XCircle`, `AlertTriangle`, `Download`, `Eye`, dll).

## 3. Perbaikan Alur & Layout yang Sudah Dikerjakan

### 3.1 Halaman "Ajukan Surat Baru" (Wizard) — **prioritas tinggi, sesuai screenshot**
Masalah pada screenshot: layout split 50/50 form vs preview PDF dipaksa tampil di lebar mobile, sehingga kartu jenis surat terlalu sempit dan preview PDF terpotong/berantakan.

Perbaikan (`LetterWizardPage.jsx`):
- Di breakpoint `< lg`: form mengambil **lebar penuh** (1 kolom), panel preview PDF **disembunyikan** dan diganti tombol **"Preview"** di header → membuka **modal bottom-sheet** berisi PDF viewer.
- Di breakpoint `≥ lg`: kembali ke layout split 50/50 seperti desain awal (form kiri, preview kanan, sticky).
- Step1 (`grid-cols-1 sm:grid-cols-2`) — kartu jenis surat full width di mobile, 2 kolom di tablet/desktop.
- Semua spacing/padding diberi varian mobile (`p-4 sm:p-6`, `text-lg sm:text-xl`, dll).
- Tombol "Kirim Pengajuan" diberi label singkat "Kirim" di mobile agar tidak overflow header.

### 3.2 Sidebar / DashboardLayout
- Warna sidebar diselaraskan: Warga = `primary`, RT/RW = `primary-dark`, Superadmin = navy paling gelap (`#0A1F5C`).
- State aktif menu memakai **aksen kuning (`#FAB95B`)** dengan teks navy — kontras tinggi, konsisten untuk semua role.
- Tombol logout memakai warna `danger` saat hover.
- Header & area konten memakai token `surface` baru (warm neutral) menggantikan `slate-50`.

### 3.3 Landing Page
- Header & hero memakai gradient `primary` → `primary-dark`.
- CTA utama ("Daftar Akun Warga") memakai aksen kuning.
- Grid fitur unggulan: `grid-cols-1` (mobile) → `sm:grid-cols-2` → `lg:grid-cols-4`, sebelumnya langsung `md:grid-cols-4` yang membuat kartu terlalu sempit di tablet.
- Footer memakai navy gelap dengan teks putih transparan.

### 3.4 Tabel Superadmin (Manajemen Akun, Log Sistem)
- Ditambahkan wrapper `overflow-x-auto` agar tabel bisa di-scroll horizontal di layar kecil tanpa merusak layout halaman.

### 3.5 Sapuan Warna Global
Dilakukan penggantian massal kelas warna lama (`blue-*`, `gray-*`, `slate-*`, `red-*`, `green-*`, `yellow-*`, `white`) ke token palet baru di **27 file** halaman/komponen (auth, dashboard warga/RT-RW/superadmin, letters, profil, QR verify), termasuk:
- `src/pages/auth/*`
- `src/pages/warga/Dashboard.jsx`
- `src/pages/rtrw/*`
- `src/pages/superadmin/*`
- `src/pages/ProfilePage.jsx`, `src/pages/QrVerifyPage.jsx`
- `src/features/letters/pages/*`

Build (`npm run build`) sudah diverifikasi sukses tanpa error setelah seluruh perubahan.

## 4. Saran Perbaikan Alur (UX) Tambahan

1. **Wizard mobile**: pertimbangkan step-by-step (1 step per layar + progress bar) untuk HP kecil, alih-alih scroll panjang berisi 5 section sekaligus — saat ini semua section langsung tampil setelah pilih jenis surat, cukup panjang di layar < 380px.
2. **Bottom navigation untuk warga di mobile**: sidebar overlay sudah ada, tapi untuk role `warga`, bottom nav bar (Dashboard, Ajukan, Status, Inbox) akan lebih cepat diakses sesuai pola aplikasi layanan publik mobile.
3. **Konsistensi badge status**: pastikan semua tempat yang menampilkan status surat (MENUNGGU/DISETUJUI/DITOLAK) memakai token `status-menunggu-*`, `status-disetujui-*`, `status-ditolak-*` — saat ini beberapa halaman masih punya badge custom dengan warna lama yang sudah ikut tersapu, tapi perlu QA visual ulang.
4. **Kontras teks di atas aksen kuning**: pastikan teks di atas `--color-accent` selalu memakai `--color-primary` (navy) atau hitam, jangan putih — kontras putih-di-atas-kuning rendah (sudah diterapkan pada sidebar & landing CTA).
5. **Dark elements check**: beberapa elemen mungkin masih memakai `text-white` di atas background terang (sisa dari tema lama) — perlu pengecekan visual per halaman, terutama `RegisterRtRw.jsx` dan `RegisterSuperadmin.jsx` yang belum di-review detail line-by-line.

## 5. Rekomendasi QA Visual

Cek manual di breakpoint berikut untuk setiap halaman (terutama Wizard, Dashboard RT/RW, Manajemen Akun):
- Mobile: 360px – 414px
- Tablet: 768px
- Desktop: ≥ 1280px

Fokus: tidak ada overflow horizontal tak sengaja, tombol tidak terpotong, warna kontras cukup (terutama teks di atas `accent` dan `primary`), tabel bisa di-scroll di mobile.
